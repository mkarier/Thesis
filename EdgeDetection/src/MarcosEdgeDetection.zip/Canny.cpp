//
// Created by marco on 11/7/17.
//

#include "Canny.h"


void CannyThreshold(int, void*)
{
    Mat c_dst, c_input, detected_edges;
    /// Reduce noise with a kernel 3x3
    blur( src_gray, detected_edges, Size(3,3) );

    /// Canny detector
    Canny( detected_edges, detected_edges, lowThreshold, lowThreshold*ratio, kernel_size );

    /// Using Canny's output as a mask, we display our result
    c_dst = Scalar::all(0);

    src_gray.copyTo( c_dst, detected_edges);
    imshow( hc_name, c_dst );
}
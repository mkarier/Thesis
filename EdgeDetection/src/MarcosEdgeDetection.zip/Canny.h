//
// Created by marco on 11/7/17.
//

#ifndef EDGEDETECTION_CANNY_H
#define EDGEDETECTION_CANNY_H

#include "OpenCVLibrary.h"


extern Mat src_gray;
extern int edgeThresh;// = 1;
extern int lowThreshold;
extern int const max_lowThreshold;// = 100;
extern int ratio;// = 3;
extern int kernel_size;// = 3;
extern char* hc_name;// = "Edge Map";

void CannyThreshold(int, void*);

#endif //EDGEDETECTION_CANNY_H

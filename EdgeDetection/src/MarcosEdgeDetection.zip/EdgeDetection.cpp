//============================================================================
// Name        : EdgeDetection.cpp
// Author      : Marco Karier
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "OpenCVLibrary.h"
#include "HighContrast.h"

using namespace std;

int read_in_style = CV_64FC1;
int threshold_value = 60;
int threshold_type = 0;
int const max_value = 255;
int const max_type = 4;
int const max_BINARY_value = 255;
int alpha = 10;
int beta = 0;

int edgeThresh = 1;
int lowThreshold;
int const max_lowThreshold = 100;
int ratio = 3;
int kernel_size = 3;

Mat input, src_gray, hc_src;
char * hc_name = "highcontrast";


int main(int argc, char * argv[])
{
	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!
	//namedWindow("original", CV_WINDOW_NORMAL);
	namedWindow("original", CV_WINDOW_NORMAL);
    namedWindow( hc_name, CV_WINDOW_NORMAL );
    input = imread(argv[1], read_in_style);
    Mat original = imread(argv[1], read_in_style);
    if (input.empty()) {
        std::cout << "!!! Failed imread()" << std::endl;
        input = imread("kana.jpg", read_in_style);
        original = imread("kana.jpg", read_in_style);
        if (input.empty()) {
            cout << "Still couldn't find the file" << endl;
            return -1;
        }
    }
    //create a Trackbar for high contrast
    createTrackbar("aplpha", hc_name, &alpha, 30, highContrast);
    createTrackbar("beta", hc_name, &beta, 100, highContrast);
    /// Create a Trackbar for user to enter threshold
    createTrackbar( "Min Threshold:", hc_name, &lowThreshold, max_lowThreshold, highContrast);
    highContrast(0,0);

    //imshow("highcontrast", hc_src);
    imshow("original", original);
    //imwrite("output.jpg", input);
    waitKey(0);
    destroyAllWindows();

	return 0;
}

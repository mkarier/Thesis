/*
 * OpenCVLibrary.h
 *
 *  Created on: Oct 19, 2017
 *      Author: marco
 */

#ifndef OPENCVLIBRARY_H_
#define OPENCVLIBRARY_H_

#include <iostream>
#include <vector>
#include <cmath>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
using namespace cv;



#endif /* OPENCVLIBRARY_H_ */
